//Hecho por Javi

package vista;

import model.Dinero;

public class VistaDinero {
	public void mostrarDineroRestante(Dinero dineroRestante) {
        System.out.println("Dinero restante por conseguir: " + dineroRestante.getBote());
    }





}
