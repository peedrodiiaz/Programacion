//Hecho por Javi
package crud;

import model.Dinero;

public class CrudDinero {
	
    public void modificarDinero(Dinero dinero, double nuevoBote) {
        dinero.setBote(nuevoBote);
    }
}