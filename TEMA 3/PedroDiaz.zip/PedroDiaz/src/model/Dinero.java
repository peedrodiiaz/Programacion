//Hecho por Javi

package model;

public class Dinero {

	private double bote;

    public Dinero(double bote) {
        this.bote = bote;
    }

    public double getBote() {
        return bote;
    }

    public void setBote(double bote) {
        this.bote = bote;
    }
}
